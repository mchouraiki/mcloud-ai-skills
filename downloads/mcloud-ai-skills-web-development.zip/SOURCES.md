# Sources and attribution

The `web-development` skill and package documentation were prepared for MCloud
Solutions by Moustafa Chouraiki.

The workflow is original MCloud Solutions material. It uses common web
development and technical SEO practices, but it does not claim to be an
official product of any framework, hosting provider or AI vendor.

License: CC BY 4.0. See `LICENSE`.
