# Web Development Skill Package

This package contains the portable `web-development` skill for reviewing and safely changing HTML, CSS, JavaScript, PHP, React and Tailwind projects.

## Use

Load `web-development/SKILL.md` according to the host tool's skill-discovery rules. The workflow is guidance, not a replacement for tests, staging, backups or engineering approval.

The skill does not assume Claude commands, named MCP tools or a particular deployment system. Use only tools available in the current session.

## License

The included workflow is original MCloud Solutions material licensed under CC BY 4.0. See `LICENSE` and `SOURCES.md`.
